/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9f1',
          100: '#dcf1de',
          200: '#bde4c2',
          300: '#94d19c',
          400: '#6ab772',
          500: '#4d8c57', // Main primary
          600: '#3d7245',
          700: '#335c3a',
          800: '#2c4a30',
          900: '#263e2a',
          950: '#112113',
        },
        secondary: {
          50: '#f6f7f0',
          100: '#e9ece0',
          200: '#d4dbc3',
          300: '#b8c5a0',
          400: '#9cad7d',
          500: '#729e78', // Main secondary
          600: '#5a7a60',
          700: '#47624d',
          800: '#3b4f3f',
          900: '#314236',
          950: '#19231c',
        },
        beige: {
          50: '#f9f9f2',
          100: '#f5f5dc', // Main beige
          200: '#e6e6c0',
          300: '#d7d7a3',
          400: '#c0c080',
          500: '#adb167',
          600: '#8d8f54',
          700: '#6e7044',
          800: '#5a5b38',
          900: '#4c4d32',
          950: '#28291a',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        heading: ['Montserrat', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out forwards',
        'slide-up': 'slideUp 0.5s ease-out forwards',
        'slide-in-right': 'slideInRight 0.5s ease-out forwards',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideInRight: {
          '0%': { transform: 'translateX(20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};