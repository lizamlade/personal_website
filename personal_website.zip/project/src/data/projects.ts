import { Project } from '../types';

export const projects: Project[] = [
  {
    id: "1",
    title: "Core Fitness App Design",
    description: "Designed and prototyped a comprehensive fitness application focusing on user experience and intuitive workout tracking. Created high-fidelity mockups and interactive prototypes using Figma.",
    tags: ["UI/UX", "Figma", "Prototyping", "Mobile Design"],
    image: "https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    link: "https://www.figma.com/design/ER1FAhImELfMC3ZWyZ9xSe/Core-Fitness-App-Design?node-id=0-1&p=f&t=L43ZGnDch8EhNurh-0",
    featured: true
  },
  {
    id: "2",
    title: "Tennis Statistics Analysis",
    description: "Developed a comprehensive statistical analysis of tennis match data using R. Implemented data visualization and statistical modeling to uncover patterns in player performance and match outcomes.",
    tags: ["R", "Data Analysis", "Statistics", "Sports Analytics"],
    image: "https://images.pixabay.com/photos/1866487/pixabay-photo-1866487.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    github: "https://github.com/lizamlade/COMP-162_project/commit/c774999de9c1a2e8c7d4efad43f7e848b45d40af",
    featured: true
  },
  {
    id: "3",
    title: "Global Happiness Report Analysis",
    description: "Analyzed worldwide happiness data using Python and Jupyter notebooks. Created visualizations and statistical models to understand factors influencing happiness across different countries.",
    tags: ["Python", "Jupyter", "Data Science", "Visualization"],
    image: "https://images.pexels.com/photos/3280130/pexels-photo-3280130.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    github: "https://github.com/lizamlade/COMP-162_project/commit/266eb1047795b9d98eb953b3136d1ea87292968f",
    featured: false
  }
];