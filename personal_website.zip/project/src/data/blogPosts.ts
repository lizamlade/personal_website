import { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "The Future of Machine Learning in Education",
    excerpt: "Exploring how AI and machine learning are transforming educational approaches and creating personalized learning experiences.",
    date: "May 15, 2024",
    readTime: "5 min read",
    tags: ["AI", "Education", "Technology"],
    image: "https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    slug: "future-of-ml-in-education"
  },
  {
    id: "2",
    title: "Building Accessible Web Applications",
    excerpt: "A comprehensive guide to creating web applications that are accessible to users with disabilities.",
    date: "April 22, 2024",
    readTime: "8 min read",
    tags: ["Web Development", "Accessibility", "Design"],
    image: "https://images.pexels.com/photos/196646/pexels-photo-196646.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    slug: "building-accessible-web-applications"
  },
  {
    id: "3",
    title: "From Theory to Practice: Applying CS Knowledge in Real Projects",
    excerpt: "How to bridge the gap between theoretical computer science concepts and practical software development.",
    date: "March 10, 2024",
    readTime: "6 min read",
    tags: ["Computer Science", "Education", "Development"],
    image: "https://images.pexels.com/photos/7092613/pexels-photo-7092613.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    slug: "from-theory-to-practice"
  }
];