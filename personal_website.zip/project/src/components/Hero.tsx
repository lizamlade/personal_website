import React from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex items-center pt-16 bg-gradient-to-br from-beige-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col lg:flex-row items-center gap-10">
          <div className="lg:w-1/2 animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold leading-tight text-gray-900 mb-4">
              Hi, I'm Liza Mladentseva
            </h1>
            <p className="text-xl md:text-2xl text-gray-700 mb-6">
              Computer Science Student & Developer
            </p>
            <p className="text-gray-600 mb-8 max-w-lg">
              I'm passionate about creating elegant solutions to complex problems
              through code. Exploring the intersection of technology, design,
              and human experience.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#projects"
                className="px-6 py-3 bg-primary-500 text-white rounded-md transition-colors hover:bg-primary-600 font-medium"
              >
                View My Work
              </a>
              <a
                href="#contact"
                className="px-6 py-3 border border-primary-500 text-primary-500 rounded-md transition-colors hover:bg-primary-50 font-medium"
              >
                Get In Touch
              </a>
            </div>
          </div>
          <div className="lg:w-1/2 flex justify-center animate-slide-up animation-delay-300">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden">
              <img
                src="https://www.picdrop.com/lizamla/61NBFCqHuw"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
        <div className="flex justify-center mt-16 animate-bounce">
          <a
            href="#about"
            className="text-gray-500 hover:text-primary-500 transition-colors"
            aria-label="Scroll down"
          >
            <ArrowDown size={28} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;