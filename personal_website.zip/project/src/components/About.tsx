import React from 'react';
import { Code, BookOpen, Globe, GraduationCap } from 'lucide-react';

interface SkillCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const SkillCard: React.FC<SkillCardProps> = ({ icon, title, description }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-100">
    <div className="text-primary-500 mb-4">{icon}</div>
    <h3 className="text-lg font-semibold text-gray-800 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-beige-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-4">
            About Me
          </h2>
          <div className="w-20 h-1 bg-primary-500 mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-600">
            I'm a computer science student with a passion for web development,
            machine learning, and solving real-world problems through technology.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <div className="animate-slide-up">
            <h3 className="text-2xl font-heading font-semibold text-gray-800 mb-4">
              My Journey
            </h3>
            <p className="text-gray-600 mb-4">
              I started my programming journey during high school when I first discovered the power of coding to create and innovate. Since then, I've been exploring various technologies and frameworks to expand my skills and knowledge.
            </p>
            <p className="text-gray-600 mb-4">
              Currently, I'm pursuing my degree in Computer Science at the University of the Pacific, focusing on AI and web development.
            </p>
            <p className="text-gray-600">
              When I'm not coding, you can find me at the tennis court, practicing my forehands, or exploring nature and traveling!
            </p>
          </div>
          <div className="animate-slide-in-right">
            <h3 className="text-2xl font-heading font-semibold text-gray-800 mb-4">
              My Skills
            </h3>
            <div className="space-y-2">
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 font-medium">JavaScript/TypeScript</span>
                  <span className="text-gray-500">90%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '90%' }}></div>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 font-medium">React & Modern Frameworks</span>
                  <span className="text-gray-500">85%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 font-medium">Python & Data Science</span>
                  <span className="text-gray-500">75%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 font-medium">UI/UX Design</span>
                  <span className="text-gray-500">70%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '70%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-12 mt-12">
          <SkillCard
            icon={<Code size={32} />}
            title="Web Development"
            description="Building responsive, accessible, and performant web applications with modern technologies."
          />
          <SkillCard
            icon={<BookOpen size={32} />}
            title="Machine Learning"
            description="Implementing intelligent systems that learn from data and make predictions."
          />
          <SkillCard
            icon={<GraduationCap size={32} />}
            title="Computer Science"
            description="Strong foundation in algorithms, data structures, and software engineering principles."
          />
        </div>
      </div>
    </section>
  );
};

export default About;