import React from 'react';
import { BlogPost } from '../types';
import { Clock } from 'lucide-react';

interface BlogCardProps {
  post: BlogPost;
}

const BlogCard: React.FC<BlogCardProps> = ({ post }) => {
  return (
    <article className="group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 flex flex-col h-full">
      <div className="relative h-48 overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex items-center text-xs text-gray-500 mb-3">
          <span>{post.date}</span>
          <span className="mx-2">•</span>
          <span className="flex items-center">
            <Clock size={14} className="mr-1" />
            {post.readTime}
          </span>
        </div>
        <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-primary-500 transition-colors">
          {post.title}
        </h3>
        <p className="text-gray-600 mb-4 flex-1">{post.excerpt}</p>
        <div className="mb-4 flex flex-wrap gap-2">
          {post.tags.map((tag) => (
            <span
              key={tag}
              className="inline-block bg-beige-100 text-secondary-700 text-xs px-3 py-1 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
        <a
          href={`#blog/${post.slug}`}
          className="inline-block text-primary-500 font-medium hover:text-primary-600 transition-colors"
        >
          Read More →
        </a>
      </div>
    </article>
  );
};

export default BlogCard;