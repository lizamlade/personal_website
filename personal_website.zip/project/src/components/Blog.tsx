import React from 'react';
import { blogPosts } from '../data/blogPosts';
import BlogCard from './BlogCard';

const Blog: React.FC = () => {
  return (
    <section id="blog" className="py-20 bg-beige-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-4">
            My Blog
          </h2>
          <div className="w-20 h-1 bg-primary-500 mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-600">
            Thoughts, ideas, and insights on technology, programming, and my journey
            as a computer science student.
          </p>
        </div>
        
        {/* Blog Posts Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map(post => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a
            href="#blog/all"
            className="inline-block px-6 py-3 bg-white border border-primary-500 text-primary-500 rounded-md transition-colors hover:bg-primary-50 font-medium"
          >
            View All Posts
          </a>
        </div>
      </div>
    </section>
  );
};

export default Blog;